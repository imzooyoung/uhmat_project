package action;

import javax.servlet.http.*;

import vo.*;

public class RestaurantModifyProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		System.out.println("RestaurantModifyProAction");
		
		return forward;
	}

}
