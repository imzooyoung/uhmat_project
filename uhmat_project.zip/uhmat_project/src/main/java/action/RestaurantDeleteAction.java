package action;

import javax.servlet.http.*;

import vo.*;

public class RestaurantDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		System.out.println("RestaurantDeleteAction");
		
		return forward;
	}

}
